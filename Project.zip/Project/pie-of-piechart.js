function Pie_of_piechart(x, y, diameter, regions, country, choice, rgb, colour, angle) {

    this.x = x;
    this.y = y;
    this.diameter = diameter;
    this.regions = regions;
    this.country = country;
    this.choice = choice;

    this.rgb = rgb;
    this.colour = colour;
    this.angle = stringsToNumbers(angle);

    // Return different index according to different choices
    this.findIndex = function (choice) {
        for (var i = 0; i < this.regions.length; i++) {
            if (choice == this.regions[i]) {
                return i;
            }
        }
    }

    // Called the function and return index
    var index = this.findIndex(this.choice);

    // Create variables for helper function
    var region = [];
    for (var i = 0; i < 5; i++) {
        region.push(this.regions[i * 10])
    }

    var countries = [];
    for (var i = 0; i < 10; i++) {
        countries.push(this.country[index + i])
    }

    this.draw = function (LHS_data, LHS_colours, RHS_data, RHS_colours, mouseX, mouseY) {

        // Check that LHS_data & RHS_data has beeen loaded successfully
        if (LHS_data.length == 0) {
            alert('LHS Data has length zero!');
        } else if (RHS_data.length == 0) {
            alert('RHS Data has length zero!');
        }

        var LHS_angles = getRadian(LHS_data);
        var LHS_Angle = this.getAngle();
        var LHS_colour;

        // Draw LHS circle
        for (var i = 0; i < LHS_data.length; i++) {

            // Calculate changes needed for line according to different choices
            var vertical = this.diameter * 0.65 * sin(LHS_angles[index / 10] / 2);
            var horizontal = this.diameter * 0.65 * cos(LHS_angles[index / 10] / 2);

            //Draw out upper and lower line
            line(this.x / 1.5 + horizontal, this.y - vertical, this.x * 1.3, this.y - this.diameter / 2);
            line(this.x / 1.5 + horizontal, this.y + vertical, this.x * 1.3, this.y + this.diameter / 2);

            // Display the colour one by one
            if (LHS_colours) {
                LHS_colour = LHS_colours[i];
            } else {
                LHS_colour = map(i, 0, LHS_data.length, 0, 255);
            }

            stroke(0, 0, 0);

            fill(LHS_colour);

            // Draw LHS closed PIE segment 
            arc(this.x / 1.5, this.y, this.diameter * 1.3, this.diameter * 1.3, LHS_Angle, LHS_Angle + LHS_angles[i] + 0.001, PIE);

            LHS_Angle += LHS_angles[i];
        }

        // Create LHS inner cirlce
        fill(255);
        ellipse(this.x / 1.5, this.y, this.diameter / 1.8);

        // Draw label for different regions
        drawlabel(5, LHS_colours, this.x - 470, this.y / 10, 20, region, 200);

        var group = [];
        for (var i = 0; i < 10; i++) {
            group.push(RHS_data[index + i]);
        }

        var RHS_angles = getRadian(group);
        var RHS_Angle = 0;
        var RHS_colour;

        // Draw RHS circle for different country
        for (var i = 0; i < RHS_data.length; i++) {
            if (RHS_colours) {
                RHS_colour = RHS_colours[i];
            } else {
                RHS_colour = map(i, 0, RHS_data.length, 0, 255);
            }

            fill(RHS_colour);

            // Draw RHS pie chart
            arc(this.x * 1.3, this.y, this.diameter, this.diameter, RHS_Angle, RHS_Angle + RHS_angles[i] + 0.001);

            RHS_Angle += RHS_angles[i];
        }

        // Draw LHS inner cirlce
        fill(255);
        ellipse(this.x * 1.3, this.y, this.diameter * 0.4)

        // Draw label for different country of RHS circle
        drawlabel(10, RHS_colours, this.x * 1.65, this.y / 10, 20, countries, 150)

        this.displayValue(mouseX, mouseY, LHS_data, RHS_data, RHS_colours);
    }

    var countryValue;

    // Return name of country according to mouse location
    this.getCountry = function (mouseX, mouseY) {
        if (dist(mouseX, mouseY, this.x * 1.3, this.y) < this.diameter / 2 &&
            dist(mouseX, mouseY, this.x * 1.3, this.y) > this.diameter * 0.2) {
            countryValue = get(mouseX, mouseY);
            for (var i = 0; i < 10; i++) {
                if (countryValue == this.rgb[index + i]) {
                    return countries[i];
                }
            }
        }
    }

    var regionValue;

    // Return percentage of region according to mouse location
    this.get_LHS_percentage = function (mouseX, mouseY, LHS_data) {
        if (dist(mouseX, mouseY, this.x / 1.5, this.y) < this.diameter * 0.65 &&
            dist(mouseX, mouseY, this.x / 1.5, this.y) > this.diameter * 0.28) {
            regionValue = get(mouseX, mouseY);
            for (var i = 0; i < this.colour.length; i++) {
                if (regionValue == this.colour[i]) {
                    return LHS_data[i / 10] / sum(LHS_data) * 100
                }
            }
        }
    }

    // Return percentage of country according to mouse location
    this.get_RHS_percentage = function (LHS_data, RHS_data) {
        for (var i = 0; i < this.rgb.length; i++) {
            if (countryValue == this.rgb[index + i]) {
                return RHS_data[index + i] / LHS_data[index / 10] * 100
            }
        }
    }

    this.displayValue = function (mouseX, mouseY, LHS_data, RHS_data) {

        // Display the name of current country
        var name = this.getCountry(mouseX, mouseY)
        if (name) {
            fill(0);
            textSize(20);
            var tWidth = textWidth(name);
            textAlign(LEFT, TOP);
            rect(mouseX, mouseY, tWidth + 20, 40);
            fill(255);
            text(name, mouseX + 10, mouseY + 10);
        }

        // Display the percentage of current region
        var LHS_percentage = this.get_LHS_percentage(mouseX, mouseY, LHS_data);
        var RHS_percentage = this.get_RHS_percentage(LHS_data, RHS_data);

        var region_percentage = LHS_data[index / 10] / sum(LHS_data) * 100;

        // Display name of selected region
        fill(255);
        textSize(13);
        textAlign('center', 'center');
        text(this.regions[index], this.x / 1.11, this.y);

        fill(0);
        textSize(20);
        textAlign('center', 'center');

        // Display percentage of certain region when mouseover
        if (LHS_percentage != undefined) {
            text(LHS_percentage.toFixed(2) + " %", this.x / 1.5, this.y);
        } else {
            text("100 %", this.x / 1.5, this.y);
        }

        textSize(15);

        //Display percentage of certain country or region selected
        if (RHS_percentage) {
            text(RHS_percentage.toFixed(2) + " %", this.x * 1.3, this.y);
        } else if (region_percentage) {
            text(region_percentage.toFixed(2) + " %", this.x * 1.3, this.y);
        } else {
            text("100 %", this.x * 1.3, this.y);
        }
    }

    // Return rotation angle needed for selected region
    this.getAngle = function () {
        for (var i = 0; i < region.length; i++) {
            if (this.choice == region[i]) {
                return this.angle[i * 10];
            }
        }
    }
}

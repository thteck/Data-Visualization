function Covid19cases() {
    //Name for the visualisation to appear in the menu bar.
    this.name = 'Covid-19 Cases';

    //Each visualisation must have unique ID with no speacial
    //characters.
    this.id = 'covid-19 cases';

    //Property to represent whether data has been loaded.
    this.loaded = false;

    // Preload the data. This function is called automatically by the
    // gallery when a visualisation is added.
    this.preload = function () {
        var self = this;
        this.data = loadTable(
            './data/covid19/Data.csv', 'csv', 'header',
            // Callback function to set the value
            // this.loaded to true.
            function (table) {
                self.loaded = true;
            });
    };

    var size;
    var regions;
    var country;
    var cases;

    var choice;

    var rgb;
    var colour;
    var angle;

    var filter;
    var number;

    this.setup = function () {

        // Check if data has been loaded successfully
        if (!this.loaded) {
            console.log('Data not yet loaded');
            return;
        }

        // Bring in data of each column
        cases = this.data.getColumn('Cases');
        regions = this.data.getColumn("Regions");
        country = this.data.getColumn("Country");

        rgb = this.data.getColumn("RGB");
        colour = this.data.getColumn("Colour");
        angle = this.data.getColumn("Angle")

        // Create a filter DOM element.
        filter = createSelect();

        // Set filter position.
        filter.position(width + 100, 100);

        // fill in filter options
        this.categories();
    }

    // Remove filter section
    this.destroy = function () {
        filter.remove();
    };

    this.draw = function () {

        number = stringsToNumbers(cases)
        var total = [];

        // Make regions cases into an array
        for (var i = 0; i < 5; i++) {
            total.push(this.recSum(i * 10));
        }

        var LHS_colours = [];
        var RHS_colours = [];

        //Push colours into both circle
        for (var i = 0; i < cases.length; i++) {
            LHS_colours.push('red', 'orange', 'yellow', 'green', 'blue');
            RHS_colours.push('coral', 'gold', 'greenyellow', 'lime', 'cyan', 'skyblue', 'magenta', 'pink', 'sandybrown', 'white');
        }

        // Create title
        fill(0);
        textAlign('center', 'center');
        textSize(30);
        strokeWeight(0);
        text('Covid-19 cases around the WORLD', width / 2, 40);

        strokeWeight(1);

        //Check mousclicked or filter has been selected
        this.swap();

        // Create new Pie-of-pie chart
        this.pie = new Pie_of_piechart(width / 2, height / 2, width / 4, regions, country, choice, rgb, colour, angle);

        this.pie.draw(total, LHS_colours, cases, RHS_colours, mouseX, mouseY);
    };

    var count = 1;

    // Sum up total cases for each regions using Recursion
    this.recSum = function (n) {
        if (count == 10) {
            count = 1;
            return number[n];
        }
        count += 1;
        return number[n] + this.recSum(n + 1);
    }

    // Shortlist number of regions
    this.categories = function () {

        var region = [""];

        //Copy value from regions to region
        for (var i = 0; i < regions.length; i++) {
            region.push(regions[i]);
        }

        //Remove duplicated value from the region
        for (var i = 0; i < region.length; i++) {
            if (region[i - 1] == region[i]) {
                region.splice(i, 10);
            }
        }

        // Push different regions into the filter
        var state = false;
        for (var i = 0; i < region.length; i++) {
            if (state == false) {
                filter.selected(region[i]);
                state = true;
            } else {
                filter.option(region[i])
            }
        }
    }
    var region_clicked;
    var click;
    // Check if any regions has been clicked on
    this.mouseClicked = function () {
        var mouse = get(mouseX, mouseY);
        for (var i = 0; i < colour.length; i++) {
            if (mouse == colour[i * 10]) {
                region_clicked = regions[i * 10];
                click = true;
            }
        }
    }

    this.swap = function () {

        //region has been selected by filter
        if (filter.value() != choice) {
            choice = filter.value();
        }
        // region has been clicked by mouse
        else if (click == true) {
            click = false;
            choice = region_clicked;
            filter.selected(region_clicked);
        }
    }
}

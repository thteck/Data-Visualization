function FoodTimeSeries() {

    //Name for the visualisation to appear in the menu bar.
    this.name = 'Food: 1974-2017';

    //Each visualisation must have unique ID with no speacial
    //characters.
    this.id = 'food-timeseries';

    //Property to represent whether data has been loaded.
    this.loaded = false;

    var bubbles = [];
    var maxAmt;
    var years = [];
    var yearsButtons = [];
    var colour;
    var name;

    //Preload the data. This function is called automatically by the
    // gallery when a visualisation is added.
    this.preload = function () {
        var self = this;
        this.data = loadTable(
            './data/food/foodData.csv', 'csv', 'header',
            // Callback function to set the value
            //this.loaded to be true.
            function (table) {
                self.loaded = true;
            });
    };

    //this is called automatically when the user click on the menu button
    this.setup = function () {
        this.datasetup();
    }

    //this is called automatically when the user click on other menu button
    this.destroy = function () {
        select("#years").html("");
    }

    this.draw = function () {

        background(100);

        if (!this.loaded) {
            console.log('Data not yet loaded');
            return;
        }

        translate(width / 2, height / 2);
        for (var i = 0; i < bubbles.length; i++) {
            bubbles[i].update(bubbles);
            bubbles[i].draw();
        }
    }

    this.datasetup = function () {

        bubbles = [];
        maxAmt;
        years = [];
        yearButtons = [];

        var rows = this.data.getRows();
        var numColumns = this.data.getColumnCount();

        for (var i = 5; i < numColumns; i++) {
            var y = this.data.columns[i];
            years.push(y);
            b = createButton(y, y);
            b.parent('years')
            b.addClass("button");
            b.id("button1")
            b.mousePressed(function () {
                changeYear(this.elt.value, years, bubbles);
            })
            yearButtons.push(b);
        }
        maxAmt = 0;

        for (var i = 0; i < rows.length; i++) {
            if (rows[i].get(0) != "") {
                colour = color(random(0, 255), random(0, 255), random(0, 255));
                name = rows[i].get(0);
                var b = new Bubble(name, colour);

                for (var j = 5; j < numColumns; j++) {
                    if (rows[i].get(j) != "") {
                        var n = rows[i].getNum(j);
                        if (n > maxAmt) {
                            maxAmt = n; //keep a tally of the highest value
                        }
                        b.data.push(n);
                    } else {
                        b.data.push(0);
                    }
                }
                bubbles.push(b);
            }
        }

        for (var i = 0; i < bubbles.length; i++) {
            bubbles[i].setMaxAmt(maxAmt);
            bubbles[i].setData(0);

        }
    }
}

function changeYear(year, _years, _bubbles) {
    var y = _years.indexOf(year);

    for (var i = 0; i < _bubbles.length; i++) {
        _bubbles[i].setData(y);
    }
}

function Bubble(_name, colour) {
    this.size = 20;
    this.target_size = 20;
    this.pos = createVector(0, 0);
    this.direction = createVector(0, 0);
    this.name = _name;
    this.color = colour
    this.data = [];

    this.draw = function () {
        push();
        textAlign(CENTER);
        noStroke();
        fill(this.color);
        ellipse(this.pos.x, this.pos.y, this.size);
        fill(0);
        textSize(15);
        text(this.name, this.pos.x, this.pos.y);
        pop();
    }

    this.update = function (_bubbles) {
        this.direction.set(0, 0);

        for (var i = 0; i < _bubbles.length; i++) {
            if (_bubbles[i].name != this.name) {
                var v = p5.Vector.sub(this.pos, _bubbles[i].pos);
                var d = v.mag();

                if (d < this.size / 2 + _bubbles[i].size / 2) {
                    if (d > 0) {

                        this.direction.add(v)
                    } else {
                        this.direction.add(p5.Vector.random2D());

                    }
                }
            }
        }

        this.direction.normalize();
        this.direction.mult(2);
        this.pos.add(this.direction);

        if (this.size < this.target_size) {
            this.size += 1;
        } else if (this.size > this.target_size) {
            this.size -= 1;
        }

    }

    this.setData = function (i) {
        this.target_size = map(this.data[i], 0, this.maxAmt, 20, 250);
    }

    this.setMaxAmt = function (_maxAmt) {
        this.maxAmt = _maxAmt;
    }
}

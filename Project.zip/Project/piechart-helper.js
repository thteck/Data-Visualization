function getRadian(data) {
    var total = sum(data)
    var radian = [];
    for (var i = 0; i < data.length; i++) {
        radian.push((data[i] / total) * TWO_PI);
    }
    return radian;
}

function drawlabel(number, colour, x, y, width, name, correction) {
    for (var i = 0; i < number; i++) {
        textAlign('left', 'center');
        textSize(15);
        fill(0);
        strokeWeight(0);
        text(name[i], x + 25, y * i + correction + 10);
        strokeWeight(1);
        fill(colour[i]);
        rect(x, y * i + correction, width, width);
    }
}
